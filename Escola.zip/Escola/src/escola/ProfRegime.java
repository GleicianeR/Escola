
package escola;


public class ProfRegime extends Professor {
    
       //Atributos da classe
    
    private double salario;

    public ProfRegime(float salario, String nome, String matricula, int idade) {
        super(nome, matricula, idade);
        this.salario = salario;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }
    
    
    
}
