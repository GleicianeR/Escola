
package escola;

public class Escola {

    public static void main(String[] args) {
        //Criando os objetos da subclasse professor Horista
        
        ProfHorista ph1 = new ProfHorista(80, "César", "123584" , 32);
        ProfHorista ph2 = new ProfHorista(25, "João", "0146587" , 45);
        ProfHorista ph3 = new ProfHorista(17, "Amarício", "9874585" , 50);
        
        
      //Criando os objetos da subclasse professor Horista  
      
      ProfRegime pr1 = new ProfRegime(1200, "Maria", "12365470" , 32);
      ProfRegime pr2 = new ProfRegime(3200, "Pedro", "12986874" , 47);
      
      //Testando os objetos
      //i:
      
      ph1.calcularSalario(30);
      ph2.calcularSalario(40);
      ph3.calcularSalario(50);
      
      //ii:
      ProfHorista[] arrayPh = new ProfHorista[3];
      arrayPh[0] = ph1;
      arrayPh[1] = ph2;
      arrayPh[2] = ph3;
      
      ProfRegime[] arrayPr = new ProfRegime[2];
      arrayPr[0] = pr1;
      arrayPr[1] = pr2;
      
     //iii:
     
      System.out.println("Professores Horistas: ");
        
         for(int i = 0; i < arrayPh.length; i++){
         
            System.out.println("Nome: " + arrayPh[i].getNome());
            System.out.println("Matricula: " + arrayPh[i].getMatricula());
            System.out.println("Idade: " + arrayPh[i].getIdade());
            System.out.println("----------------------");
         
     }
         
       System.out.println("Professores Regime fechado: ");
       
         for(int i = 0; i < arrayPr.length; i++){
         
            System.out.println("Nome: " + arrayPr[i].getNome());
            System.out.println("Matricula: " + arrayPr[i].getMatricula());
            System.out.println("Idade: " + arrayPr[i].getIdade());
            System.out.println("----------------------");
         
     }
        
    }
    
}
