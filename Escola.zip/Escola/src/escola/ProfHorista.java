
package escola;


public class ProfHorista extends Professor {
    
    //Atributos da classe
    
    private int horasAula;
    private double salarioHora;

    public ProfHorista(int horasAula, String nome, String matricula, int idade) {
        super(nome, matricula, idade);
        this.horasAula = horasAula;
      
    }


    public int getHorasAula() {
        return horasAula;
    }

    public void setHorasAula(int horasAula) {
        this.horasAula = horasAula;
    }

    public double getSalarioHora() {
        return salarioHora;
    }

    public void setSalarioHora(int salarioHora) {
        this.salarioHora = salarioHora;
    }
    
    //Metodo que calcula o salario hora
    
    public void calcularSalario(double valorHoraAula) {
        this.salarioHora = this.horasAula * valorHoraAula;
    }
    
    
}
